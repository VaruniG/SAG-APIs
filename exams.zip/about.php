<?php

require 'dbconnect.php';
$id=$_REQUEST['id'];
$query="select * from exams where exam_id = $id";
$run=mysqli_query($connection, $query);
if(mysqli_num_rows($run) > 0)
{
$url="internmania.com/SAG/About/".$id.".pdf";
print(json_encode($url));
}

?>