<?php

//for user login


$response = array();
require 'dbconnect.php';
if(!$connection)
{
	$response["success"] = 0;
	$response["message"] = "unable to reach database";
}

else if(!isset($_REQUEST['email']) AND !isset($_REQUEST['password']))
{
	$response["success"] = 0;
	$response["message"] = "mandatory field(s) missing";
}

else
{
	$email=$_REQUEST['email'];
	$password=$_REQUEST['password'];
	$query = "select * from userdata where email = '$email' ";
	$fire = mysqli_query($connection,$query);
	$result = mysqli_fetch_array($fire);
	$actpwd = $result['password'];
	if($actpwd == $password)
	{
		$response["success"] = 1;
		$response["user_id"] = $result	
	}
	if(mysqli_query($connection,$query))
	{
		$id=mysqli_insert_id($connection);
		$response["success"] = 1;
		$response["message"] = "Signup Success";
		$response["id"] = $id;
	}
	else
	{
		$response["message"]="Unable to execute query";
	}	
	mysqli_close($connection);
}
print(json_encode($response));

?>